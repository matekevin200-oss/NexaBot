# NEXA Bot 22.1.1 — MDT Network

A felhasználónak a generált `index.js` fájlt kell lecserélnie a meglévő botban. Az éles függőségek változatlanok: discord.js, dotenv, pg; Node >=22. A teljes beállítási útmutató a forrásmentésben `NEXA-22-UTMUTATO.md` néven található.

A `src` könyvtár az indexbe csomagolt modulokat tartalmazza. `python bundle.py` újra előállítja az egyfájlos botot a module-order.txt és a bundle-header/footer alapján. A mdt-client.lua a src/mdt-client.js-be beépített játékkliens forrása.

Az MDT web a bot Render-szolgáltatásán belül, `/mdt-web` alatt van. A NEXA `/mdt` menüpontja erre az útvonalra vezet. A `render-web` tartalmazza a felület forrását; `python embed-web.py` beépíti a botba, majd `python bundle.py` előállítja az egyetlen telepítendő index.js fájlt. A Discord OAuth és az RP-adatok ugyanazon szolgáltatás háttérrendszerében maradnak.

Ellenőrzés: `npm install`, `npm test`; Lua szintaxis: `python test/check-lua.py`, ha liblua5.4 elérhető. A kiadáshoz valódi PostgreSQL-motorral és szimulált Discord API-val futtatott tesztek tartoznak. Éles Discord/Roblox hitelesítő adat nincs a csomagban.
