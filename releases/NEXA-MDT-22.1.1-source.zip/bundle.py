from pathlib import Path
root=Path(__file__).parent
order=(root/'module-order.txt').read_text().splitlines()
modules=['"'+name+'": function(module, exports, require) {\n'+(root/name).read_text().rstrip('\n')+'\n\n}' for name in order]
(root/'index.js').write_text((root/'bundle-header.txt').read_text()+',\n'.join(modules)+(root/'bundle-footer.txt').read_text())
print('Bundled',len(modules),'modules')
