from pathlib import Path
import json
p=Path(__file__).parent/'render-web'
assets={}
for path,mime in [('index.html','text/html; charset=utf-8'),('auth-complete.html','text/html; charset=utf-8'),('assets/mdt.css','text/css; charset=utf-8'),('assets/mdt-app.js','application/javascript; charset=utf-8'),('assets/mark.svg','image/svg+xml')]:
 key='/mdt-web' if path=='index.html' else '/'+path
 assets[key]={'body':(p/path).read_text(),'type':mime}
assets['/mdt-web/']=assets['/mdt-web']
(Path(__file__).parent/'src/mdt-web-assets.js').write_text('module.exports={assets:'+json.dumps(assets,ensure_ascii=False,separators=(',',':'))+'};\n')
