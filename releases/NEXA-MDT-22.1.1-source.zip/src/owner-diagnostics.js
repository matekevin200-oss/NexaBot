const { databaseHealth,checkDatabaseConnection,isBotOwner,getGuildConfig }=require('./config');
const { SUPPORT_GUILD_ID }=require('./constants');
const {getSettings}=require('./belv-mdt');
const {FACTIONS}=require('./mdt-factions');
async function diagnosticState(client,actorId,verify=false) {
 if(!isBotOwner(actorId))throw Object.assign(new Error('A diagnosztikát csak a fő owner használhatja.'),{status:403});
 if(verify)await checkDatabaseConnection();
 const health=databaseHealth(),checks=[{name:'Discord-kapcsolat',ok:Boolean(client.isReady?.()),detail:client.isReady?.()?'A bot kapcsolódott.':'A bot még csatlakozik vagy újracsatlakozik.'},{name:'PostgreSQL',ok:health.persistent&&health.state==='online',detail:health.state==='online'?'A tároló elérhető.':'Ellenőrizd a DATABASE_URL beállítást és az adatbázis elérhetőségét.'}];
 const support=client.guilds.cache.get(SUPPORT_GUILD_ID);
 checks.push({name:'NEXA Support',ok:Boolean(support),detail:support?(getGuildConfig(SUPPORT_GUILD_ID).supportModeration.paused?'Moderáció szünetel.':'Moderáció a beállított kapcsolók szerint.'): 'A bot nincs a hivatalos Support szerveren.'});
 for(const faction of FACTIONS){const guild=client.guilds.cache.get(faction.guildId);checks.push({name:faction.name+' szerver',ok:Boolean(guild),detail:guild?'Az engedélyezett frakció szervere elérhető.':'A bot nincs ezen a megadott szerveren.'});
 if(guild&&health.persistent){const settings=await getSettings(guild.id);checks.push({name:faction.name+' MDT',ok:settings.enabled===true,detail:settings.enabled?`${settings.members?.length||0} felvett tag; ${(settings.robloxIds||[]).length} owner Roblox-ID.`:'Az MDT nincs bekapcsolva. A külön web Kapcsolatok oldalán aktiválható.'});
 for(const[label,id]of[['alapcsatorna',settings.defaultChannelId],['bírálati csatorna',settings.reviewChannelId]]){const channel=id?guild.channels.cache.get(id):null,bot=guild.members.me,okay=Boolean(channel&&bot&&['ViewChannel','SendMessages','EmbedLinks','ReadMessageHistory'].every(bit=>channel.permissionsFor(bot)?.has(bit))&&(label!=='bírálati csatorna'||channel.permissionsFor(guild.roles.everyone)?.has('ViewChannel')===false));checks.push({name:faction.name+' MDT '+label,ok:okay,detail:okay?'A célcsatorna és a bot szükséges jogai rendben vannak.':'Válassz megfelelő célcsatornát. A bírálati csatorna legyen privát.'});}}
 }

 return{checks,checkedAt:new Date().toISOString()};
}
async function diagnosticsPage(client,session,helpers,verify=false) {
 const {layout,escapeHtml:escape}=helpers,state=await diagnosticState(client,session.user.id,verify);
 return layout('NEXA • Rendszerellenőrzés',`<div class="page-head"><div><h1>Rendszerellenőrzés</h1><p class="muted">A saját bot és a hozzá tartozó szolgáltatások aktuális állapota.</p></div><a class="btn secondary" href="/owner">← Owner Center</a></div><section class="card section"><div style="overflow-x:auto"><table><thead><tr><th>Ellenőrzés</th><th>Állapot</th><th>Teendő</th></tr></thead><tbody>${state.checks.map(check=>`<tr><td>${escape(check.name)}</td><td>${check.ok?'✅ Rendben':'⚠️ Ellenőrizendő'}</td><td>${escape(check.detail)}</td></tr>`).join('')}</tbody></table></div><p class="muted">Lekérdezés: ${escape(state.checkedAt)}</p><form method="post" action="/owner/diagnostics"><input type="hidden" name="csrf" value="${escape(session.csrf)}"><button class="btn green" type="submit">Kapcsolatok újraellenőrzése</button></form><div class="actions"><a class="btn secondary" href="/owner/mdt">MDT Network kezelése</a><a class="btn secondary" href="/owner/support">Support műveletek</a></div></section>`,session);
}
module.exports={diagnosticState,diagnosticsPage};
