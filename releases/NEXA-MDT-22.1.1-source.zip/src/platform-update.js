const { recordError, recordAudit } = require('./telemetry');

// Remove obsolete application commands only; existing guild resources are retained.
async function retireLegacyCommands(client) {
  const result = { removed: [], failed: [] };
  for (const guild of client.guilds.cache.values()) {
    if (!guild.commands) continue;
    try {
      const commands = await guild.commands.fetch();
      for (const command of commands.values()) {
        if (command.name !== 'crown-city') continue;
        await command.delete();
        result.removed.push(guild.id);
        await recordAudit('retired_command_remove', { guildId: guild.id, targetId: command.id });
      }
    } catch (error) {
      result.failed.push(guild.id);
      await recordError(error, { command: 'retired_command_cleanup', guildId: guild.id }).catch(() => null);
    }
  }
  return result;
}

module.exports = { retireLegacyCommands };
