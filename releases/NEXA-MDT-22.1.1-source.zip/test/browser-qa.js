const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {databaseProject}=require('./database'),{fixtures,OWNER,USER,ROLE}=require('./fixtures');
const {chromium:playwright}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const chromium=require('@sparticuz/chromium').default;
process.env.DATABASE_URL='postgres://local-test.invalid/nexa';process.env.BOT_OWNER_ID=OWNER;process.env.PUBLIC_URL='https://nexa-qa.example';process.env.SESSION_SECRET='local-qa-only-secret-of-at-least-32-characters';
(async()=>{
 let app,browser;const checks=[];
 try {
  app=await databaseProject({additionalExports:{dashboard:['layout','settingsPage','webSupportPage','webSupportTicketPage','ownerSupportTicketPage','dashboardClientScript']}});assert.equal(await app.config.initConfigStore(),true);
  const ui=app.load('dashboard'),belv=fixtures('1517509643734221030'),base=app.config.getGuildConfig(belv.guild.id);
  const current=await app.config.setGuildConfig(belv.guild.id,{...base,modules:{...base.modules,tickets:true},tickets:{...base.tickets,customTypes:[{key:'appeal-1',label:'Fellebbezés'}],enabledTypes:['support','appeal-1'],questions:[{label:'Roblox-név',required:true}]}});
  const channel=belv.channel(),review=belv.channel('review');await app.load('belv-mdt').saveMdtOwnerConfig(belv.guild,OWNER,{enabled:false,robloxIds:['101'],defaultChannelId:channel.id,reviewChannelId:review.id});
  const session={user:{id:OWNER,username:'Local QA Owner'},csrf:'local-csrf-value',language:'hu',guilds:[],currentPath:'/owner'};
  const ticket={id:1,user_id:USER,username:'QA User',subject:'Ékezetes próba <script>bad()</script>',status:'open',priority:'normal',assigned_name:null,revision:1,discord_state:'synced',created_at:new Date(),updated_at:new Date(),metrics:{targetHours:24},form_data:{}};
  const messages=[{id:1,source:'web',author_name:'QA User',content:'Próbaüzenet <img src=x onerror=bad()>',created_at:new Date()}];
  const supportOptions=ui.layout('Support ügykezelési lehetőségek',`<section class="card section"><form method="post" action="/owner/support/options"><input type="hidden" name="csrf" value="${session.csrf}">${app.load('workflow-ui').ticketAdvancedFields(current.tickets,belv.guild,ui.escapeHtml)}<button type="submit">Mentés</button></form></section>`,session);
  const pages={settings:ui.settingsPage(belv.guild,current,session),mdt:await app.load('mdt-owner').mdtOwnerPage(belv.client,session,belv.guild.id,ui),options:supportOptions,diagnostics:await app.load('owner-diagnostics').diagnosticsPage(belv.client,session,ui),support:await ui.webSupportTicketPage({ticket,messages},session),ownerSupport:await ui.ownerSupportTicketPage({ticket,messages},session)};
  new Function(ui.dashboardClientScript());checks.push('Dashboard JavaScript compiles');
  let executablePath=process.env.NEXA_QA_CHROMIUM_PATH||'/tmp/chromium';
  if(!fs.existsSync(executablePath)){try{executablePath=await chromium.executablePath();}catch(error){if(!fs.existsSync(executablePath))throw error;}}
  browser=await playwright.launch({executablePath,args:chromium.args,headless:true});
  const page=await browser.newPage();
  for(const width of [1440,390]) {
   await page.setViewportSize({width,height:900});
   for(const [name,html] of Object.entries(pages)) {
    const errors=[];page.removeAllListeners('pageerror');page.on('pageerror',e=>errors.push(e.message));
    await page.unroute('**/*');await page.route('**/*',async route=>{
     const url=new URL(route.request().url());
     if(url.pathname==='/assets/nexa-dashboard.js')return route.fulfill({status:200,contentType:'application/javascript',body:ui.dashboardClientScript()});
     if(url.pathname==='/api/support/1')return route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({ok:true,ticket:{...ticket,status:'pending',revision:2,assigned_name:'New agent'},messages:[...messages,{id:2,source:'owner',author_name:'Owner',content:'Latest synchronized reply',created_at:new Date()}]})});
     if(url.pathname.startsWith('/api/'))return route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({ok:true,notifications:[],counts:{}})});
     if(url.origin==='http://qa.local')return route.fulfill({status:200,contentType:'text/html',body:html});
     return route.fulfill({status:204,body:''});
    });
    await page.goto('http://qa.local/'+name,{waitUntil:'networkidle'});
    assert.deepEqual(errors,[],name+' '+width+' JavaScript errors');
    const size=await page.evaluate(()=>({page:document.documentElement.scrollWidth,screen:innerWidth,main:document.querySelector('main').getBoundingClientRect().width}));if(width===390)assert.ok(size.main>=350,name+' mobile main width: '+size.main);assert.ok(size.page<=size.screen+2,name+' '+width+' horizontal overflow: '+JSON.stringify(size));
    if(name==='settings') {assert.equal(await page.locator('[name=ticket_max_open]').count(),1);assert.equal(await page.locator('[name=protection_capsPercent]').count(),1);}
    if(name==='mdt'){assert.equal(await page.locator('[name=type_arrest]').count(),1);assert.equal(await page.locator('[name=mdt_version]').count(),4);}
    if(name==='support'||name==='ownerSupport'){await page.waitForFunction(()=>document.querySelector('[data-support-messages]')?.textContent.includes('Latest synchronized reply'),{timeout:5000});assert.equal(await page.locator('script').count(),1);assert.ok(!(await page.evaluate(()=>Object.hasOwn(window,'bad'))));}
    if(name==='options'){await page.locator('[name=ticket_max_open]').fill('3');const data=await page.evaluate(()=>Object.fromEntries(new FormData(document.querySelector('form'))));assert.equal(data.ticket_max_open,'3');assert.equal(data.csrf,session.csrf);}
    fs.mkdirSync(path.join(__dirname,'../qa'),{recursive:true});if(width===390&&['settings','mdt'].includes(name))await page.screenshot({path:path.join(__dirname,'../qa',name+'-mobile.png'),fullPage:false});
    checks.push(name+' renders and runs at '+width+'px');
   }
  }
  fs.writeFileSync(path.join(__dirname,'../browser-results.json'),JSON.stringify({passed:checks.length,checks},null,2));console.log(JSON.stringify({browserChecks:checks.length,passed:true}));
 } finally {await browser?.close();await app?.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
