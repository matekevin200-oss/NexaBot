import ctypes,json
from pathlib import Path
root=Path(__file__).resolve().parent.parent
library=ctypes.CDLL('liblua5.4.so.0')
library.luaL_newstate.restype=ctypes.c_void_p
library.luaL_loadbufferx.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_size_t,ctypes.c_char_p,ctypes.c_char_p]
library.luaL_loadbufferx.restype=ctypes.c_int
library.lua_tolstring.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p]
library.lua_tolstring.restype=ctypes.c_char_p
library.lua_close.argtypes=[ctypes.c_void_p]
source=(root/'mdt-client.lua').read_bytes()
state=library.luaL_newstate()
try:
 result=library.luaL_loadbufferx(state,source,len(source),b'NEXA MDT Network 4.0',b't')
 if result:raise RuntimeError(library.lua_tolstring(state,-1,None).decode())
 print('Lua 5.4 syntax: passed')
 (root/'lua-results.json').write_text(json.dumps({'luaVersion':'5.4','syntax':'passed','bytes':len(source)},indent=2))
finally:library.lua_close(state)
