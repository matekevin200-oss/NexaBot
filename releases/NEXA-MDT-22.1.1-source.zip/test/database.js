const {PGlite}=require('@electric-sql/pglite');
const {loadProject}=require('./loader');
async function databaseProject(options={}) {
  const database=new PGlite();await database.waitReady;
  let simulateError=null;
  class Pool {
    on(){}
    async end(){}
    async query(sql,values=[]) {
      if(simulateError&&(!simulateError.match||simulateError.match.test(sql))){const error=simulateError.error;simulateError=null;throw error;}
      const parameters=values.map(value=>typeof value==='object'&&value!==null&&!(value instanceof Date)&&!Array.isArray(value)?JSON.stringify(value):value);
      const results=parameters.length?[await database.query(sql,parameters)]:await database.exec(sql);
      const result=results.at(-1)||{};
      return{...result,rows:result.rows||[],rowCount:result.rows?.length||result.affectedRows||0};
    }
  }
  const load=loadProject({'pg':{Pool},...(options.overrides||{})},undefined,options);
  const config=load('config');
  return {database,load,config,failNext(error,match=null){simulateError={error,match};},async close(){await config.closeConfigStore();await database.close();}};
}
module.exports={databaseProject};
