const {Collection,ChannelType}=require('discord.js');
const OWNER='100000000000000002',USER='100000000000000008',OTHER='100000000000000009',BOT='100000000000000099',ROLE='100000000000000014';
let sequence=100000000000000200n;
function fixtures(id) {
 const members=new Collection(),channels=new Collection(),roles=new Collection([[ROLE,{id:ROLE,name:'Support Staff',managed:false}],[id,{id,name:'@everyone',managed:false}]]);
 const client={user:{id:BOT},isReady:()=>true,channels:{cache:channels,fetch:async id=>channels.get(id)},guilds:{cache:new Collection()}};
 const guild={id,name:'Local QA Guild',ownerId:OWNER,memberCount:4,client,roles:{cache:roles,everyone:roles.get(id),fetch:async()=>roles},channels:{cache:channels,fetch:async()=>channels},autoModerationRules:{fetch:async()=>new Collection()}};
 client.guilds.cache.set(id,guild);
 function member(id,roleIds=[]) {const m={id,guild,displayName:id===OWNER?'Owner':'QA Member',user:{id,username:'qa_user',tag:'qa_user',bot:id===BOT,createdTimestamp:Date.now()-86400000*100},roles:{cache:new Collection(roleIds.map(id=>[id,roles.get(id)]))},permissions:{has:()=>id===BOT},kickable:true,bannable:true,moderatable:true,toString(){return '<@'+id+'>';}};members.set(id,m);return m;}
 guild.members={cache:members,fetch:async query=>{const m=members.get(typeof query==='string'?query:query.user);if(!m)throw new Error('Unknown member');return m;},fetchMe:async()=>members.get(BOT)};
 guild.members.me=member(BOT);member(OWNER);member(USER);member(OTHER,[ROLE]);
 function channel(name='mdt-records',type=ChannelType.GuildText) {
  const messages=new Collection(),ch={id:String(sequence++),name,type,guild,parentId:null,topic:null,isTextBased:()=>type===ChannelType.GuildText,isThread:()=>false,toString(){return '<#'+this.id+'>';},permissionsFor:subject=>({has:()=>subject?.id!==guild.id}),permissionOverwrites:{cache:new Collection(),edit:async()=>true},messages:{cache:messages,fetch:async key=>{if(typeof key==='object')return messages;const m=messages.get(key);if(!m)throw Object.assign(new Error('Unknown message'),{code:10008});return m;}},async setName(value){this.name=value;return this;},async delete(){channels.delete(this.id);return this;},async send(payload){for(const embed of payload.embeds||[])embed.toJSON();for(const row of payload.components||[])row.toJSON();const m={id:String(sequence++),author:{id:BOT},embeds:payload.embeds||[],components:payload.components||[],async edit(next){for(const embed of next.embeds||[])embed.toJSON();Object.assign(this,next);return this;}};messages.set(m.id,m);return m;}};
  channels.set(ch.id,ch);return ch;
 }
 guild.channels.create=async options=>{const ch=channel(options.name,options.type);ch.topic=options.topic;ch.parentId=options.parent;ch.createOptions=options;return ch;};
 guild.roles.create=async options=>{const role={id:String(sequence++),...options};roles.set(role.id,role);return role;};
 function interaction(customId,userId=OTHER,ch=null,values={}) {const user=members.get(userId).user,result={guild,guildId:id,channel:ch,channelId:ch?.id,user,member:members.get(userId),client,customId,fields:{getTextInputValue:key=>String(values[key]||'')},async deferReply(){this.deferred=true;},async reply(payload){this.result=payload;},async editReply(payload){this.result=payload;},async showModal(modal){this.modal=modal;}};return result;}
 return{client,guild,members,channels,roles,member,channel,interaction};
}
module.exports={fixtures,OWNER,USER,OTHER,BOT,ROLE};
