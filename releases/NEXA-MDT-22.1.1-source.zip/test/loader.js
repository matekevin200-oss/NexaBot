const fs=require('node:fs'),path=require('node:path');
function loadProject(overrides={},sourceRoot=path.join(__dirname,'../src'),options={}) {
  const cache=new Map();
  const load=(name)=>{
    if(cache.has(name))return cache.get(name).exports;
    const module={exports:{}};cache.set(name,module);
    let code=fs.readFileSync(path.join(sourceRoot,name+'.js'),'utf8');
    if(options.additionalExports?.[name])code+='\nObject.assign(module.exports,{'+options.additionalExports[name].join(',')+'});';
    const request=(target)=>{
      if(Object.hasOwn(overrides,target))return overrides[target];
      if(target.startsWith('.'))return load(target.slice(2));
      return require(target);
    };
    try{new Function('module','exports','require',...Object.keys(options.bindings||{}),code)(module,module.exports,request,...Object.values(options.bindings||{}));}catch(error){cache.delete(name);throw error;}
    return module.exports;
  };
  return load;
}
module.exports={loadProject};
