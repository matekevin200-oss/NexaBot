const {databaseProject}=require('./database');
process.env.DATABASE_URL='postgres://local-test.invalid/nexa';process.env.BOT_OWNER_ID='100000000000000002';
(async()=>{
 const app=await databaseProject();
 const result=await app.config.initConfigStore();console.log('DB initialization',result,app.config.databaseHealth());
 if(result){const tables=await app.database.query("SELECT COUNT(*)::integer AS total FROM information_schema.tables WHERE table_schema='public'");console.log('tables',tables.rows);}
 await app.close();if(!result)process.exitCode=1;
})().catch(error=>{console.error(error);process.exitCode=1;});
