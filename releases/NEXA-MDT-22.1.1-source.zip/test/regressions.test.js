const test=require('node:test'),assert=require('node:assert/strict');
const {databaseProject}=require('./database');
const {Collection,EmbedBuilder}=require('discord.js');
process.env.DATABASE_URL='postgres://local-test.invalid/nexa';process.env.BOT_OWNER_ID='100000000000000002';
const OWNER=process.env.BOT_OWNER_ID,GUILD='1517509643734221030';
let app;
test.before(async()=>{app=await databaseProject();assert.equal(await app.config.initConfigStore(),true);});
test.after(async()=>{await app.close();});
test('a failed guild save retains the last confirmed configuration',async()=>{
 const original=await app.config.setGuildConfig(GUILD,{...app.config.getGuildConfig(GUILD),language:'en'});
 app.failNext(Object.assign(new Error('Simulated write constraint'),{code:'23514'}));
 await assert.rejects(app.config.setGuildConfig(GUILD,{...original,language:'hu'}));
 assert.equal(app.config.getGuildConfig(GUILD).language,'en');
});
test('a SQL validation error does not falsely mark the connected database offline',async()=>{
 await app.config.dbQuery('SELECT 1');
 await assert.rejects(app.config.dbQuery('SELECT missing_field FROM nexabot_guild_configs'),e=>e.code==='42703');
 assert.equal(app.config.isPersistentStore(),true);
});
test('a failed owner save does not silently change global module switches',async()=>{
 await app.config.dbQuery('SELECT 1');await app.config.setOwnerSettings({maintenance:false});
 app.failNext(Object.assign(new Error('Simulated write constraint'),{code:'23514'}));
 await assert.rejects(app.config.setOwnerSettings({maintenance:true}));assert.equal(app.config.getOwnerSettings().maintenance,false);
});
test('web ticket state changes preserve the original question in Discord',async()=>{
 await app.config.dbQuery('SELECT 1');
 const inserted=await app.database.query("INSERT INTO nexabot_web_support_tickets(user_id,username,subject,category,channel_id,control_message_id) VALUES($1,'Member','Original problem','technical',$2,$3) RETURNING *",['100000000000000008','100000000000000020','100000000000000030']);
 const ticket=inserted.rows[0];
 await app.database.query("INSERT INTO nexabot_web_support_messages(ticket_id,author_id,author_name,source,content,discord_message_id) VALUES($1,$2,'Member','web','The original problem must remain readable',$3)",[ticket.id,ticket.user_id,ticket.control_message_id]);
 const original={id:ticket.control_message_id,author:{id:'100000000000000099'},embeds:[new EmbedBuilder().setDescription('The original problem must remain readable')],async edit(payload){this.embeds=payload.embeds;return this;}};
 const messages=new Collection([[original.id,original]]);let count=40;
 const channel={id:ticket.channel_id,name:'web-1-member',isTextBased:()=>true,async setName(name){this.name=name;},messages:{fetch:async id=>messages.get(id)},async send(payload){const message={id:String(100000000000000000n+BigInt(count++)),author:{id:'100000000000000099'},embeds:payload.embeds,async edit(data){this.embeds=data.embeds;return this;}};messages.set(message.id,message);return message;}};
 const client={channels:{cache:new Collection([[channel.id,channel]]),fetch:async()=>channel},guilds:{cache:new Collection()}};
 await app.load('web-support').manageWebTicket(client,ticket.id,{id:OWNER,username:'Owner'},'claim');
 assert.ok(original.embeds.some(embed=>embed.data.description.includes('The original problem must remain readable')));
});
