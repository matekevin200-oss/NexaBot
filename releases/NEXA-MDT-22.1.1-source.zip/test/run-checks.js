const {spawn}=require('node:child_process'),fs=require('node:fs'),path=require('node:path');
const target=path.resolve(__dirname,'../integration-results.log');const files=fs.readdirSync(__dirname).filter(name=>name.endsWith('.test.js')).map(name=>path.join(__dirname,name));
const child=spawn(process.execPath,['--test','--test-isolation=none','--test-reporter=tap',...files],{cwd:path.resolve(__dirname,'..'),stdio:['ignore','pipe','pipe']});
let output='';child.stdout.on('data',chunk=>{output+=chunk;});child.stderr.on('data',chunk=>{output+=chunk;});
child.on('error',error=>{console.error(error);process.exitCode=1;});
child.on('close',code=>{fs.writeFileSync(target,output);const lines=output.split('\n');console.log(lines.filter(line=>/^not ok|^# (tests|pass|fail|duration)/.test(line)).join('\n')||output);if(code)process.exitCode=code;});
