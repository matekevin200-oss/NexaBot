const test=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {Readable}=require('node:stream');
const {databaseProject}=require('./database');
const {fixtures,OWNER,USER,OTHER,ROLE}=require('./fixtures');
const {ChannelType,Collection}=require('discord.js');
process.env.DATABASE_URL='postgres://local-test.invalid/nexa';process.env.BOT_OWNER_ID=OWNER;process.env.SESSION_SECRET='local-qa-secret-123456789';
const BELV='1517509643734221030',SUPPORT='1556219615858655254';
let app,mdt,web,belv,support,settings,ctx,record,webTicket;
const key=()=>crypto.randomBytes(16).toString('hex');
test.before(async()=>{
 app=await databaseProject();assert.equal(await app.config.initConfigStore(),true);mdt=app.load('belv-mdt');web=app.load('web-support');belv=fixtures(BELV);support=fixtures(SUPPORT);
 const destination=belv.channel(),review=belv.channel('mdt-review');
 settings=await mdt.saveMdtOwnerConfig(belv.guild,OWNER,{enabled:true,robloxIds:['101'],members:[{discordId:USER,robloxIds:['102']},{discordId:OTHER,robloxIds:['103']}],defaultChannelId:destination.id,reviewChannelId:review.id,allowSelfReview:false,codeMinutes:2,sessionMinutes:15,pageSize:10});
 ctx={guild:belv.guild,member:belv.members.get(USER),settings};
 support.channel('TICKETS',ChannelType.GuildCategory);
 const current=app.config.getGuildConfig(SUPPORT);await app.config.setGuildConfig(SUPPORT,{...current,roles:{...current.roles,staff:ROLE},tickets:{...current.tickets,webMaxOpenPerUser:2}});
});
test.after(async()=>{await app.close();});
test('MDT rejects every guild except the pinned Belv guild',async()=>{await assert.rejects(mdt.getSettings(SUPPORT),e=>e.status===403);});
test('MDT settings cannot be overwritten by a stale owner form',async()=>{
 const next=await mdt.saveMdtOwnerConfig(belv.guild,OWNER,{...settings,pageSize:20});await assert.rejects(mdt.saveMdtOwnerConfig(belv.guild,OWNER,{...settings,pageSize:30}),e=>e.status===409);
 settings=next;ctx.settings=next;assert.equal((await mdt.getSettings(BELV)).pageSize,20);
});
test('non-owner cannot change MDT membership or settings',async()=>{await assert.rejects(mdt.updateMdtMember(belv.guild,USER,{discordId:OTHER,robloxIds:'103'}),e=>e.status===403);});
test('one Roblox ID cannot belong to two Discord accounts',async()=>{await assert.rejects(mdt.updateMdtMember(belv.guild,OWNER,{discordId:OTHER,robloxIds:'102'}),e=>e.status===400);});
test('the four new record types are visible to registered members',()=>{const types=mdt.definitions(belv.guild,ctx.member,settings);for(const name of ['arrest','fine','evidence','dispatch'])assert.ok(types.some(type=>type.key===name));});
test('an unregistered guild member cannot open the MDT',()=>{assert.throws(()=>mdt.assertAccess(belv.guild,belv.member('100000000000000011'),settings),e=>e.status===403);});
test('a valid personal login is single use and bound to Roblox ID',async()=>{
 const code=await mdt.issueCode(belv.guild,ctx.member),session=await mdt.login(belv.client,code,'102',BELV);
 assert.ok(new Date(session.expiresAt).getTime()-Date.now()<16*60000);
 assert.equal((await mdt.authorize(belv.client,'Bearer '+session.token,'102')).member.id,USER);
 await assert.rejects(mdt.authorize(belv.client,'Bearer '+session.token,'103'),e=>e.status===403);
 await assert.rejects(mdt.login(belv.client,code,'102',BELV),e=>e.status===401);
});
test('member codes expire according to the configured duration',async()=>{
 await mdt.issueCode(belv.guild,belv.members.get(OTHER));const row=(await app.database.query('SELECT expires_at FROM nexabot_mdt_codes WHERE user_id=$1',[OTHER])).rows[0];assert.ok(new Date(row.expires_at).getTime()-Date.now()<3*60000);
});
test('MDT create, retry and content mismatch use one stored record',async()=>{
 const body={key:'arrest',clientKey:key(),fields:{target:'Test RP person',robloxId:'9001',reason:'RP test incident',location:'Training area',charges:'Test charge'}};
 record=(await mdt.createRecord(ctx,body)).row;assert.equal(record.status,'pending');assert.equal(record.discord_state,'synced');
 const retry=await mdt.createRecord(ctx,body);assert.equal(String(retry.row.id),String(record.id));assert.equal(retry.duplicate,true);
 await assert.rejects(mdt.createRecord(ctx,{...body,fields:{...body.fields,reason:'Changed text'}}),e=>e.status===409);
});
test('self review policy blocks creator but allows another registered member',async()=>{
 await assert.rejects(mdt.mutateRecord(ctx,record.id,{revision:record.revision,decision:'approve'},'review'),e=>e.status===403);
 const otherCtx={...ctx,member:belv.members.get(OTHER)};const result=await mdt.mutateRecord(otherCtx,record.id,{revision:record.revision,decision:'approve'},'review');record=result.row;assert.equal(record.status,'published');assert.equal(record.reviewed_by,OTHER);
});
test('MDT rejects old revisions and records review history',async()=>{
 await assert.rejects(mdt.mutateRecord(ctx,record.id,{revision:1},'archive'),e=>e.status===409);
 const history=await mdt.recordHistory(ctx,record.id);assert.equal(history.history.length,2);assert.equal(history.history[0].revision,2);
});
test('new fine records validate amounts and link to readable same-guild records',async()=>{
 const fields={target:'Test RP person',amount:'125.50',reason:'RP traffic test',location:'Training area',linkedRecordId:String(record.id)};
 const result=await mdt.createRecord(ctx,{key:'fine',clientKey:key(),fields});assert.equal(result.row.fields.linkedRecordId,String(record.id));
 await assert.rejects(mdt.createRecord(ctx,{key:'fine',clientKey:key(),fields:{...fields,amount:'not a number'}}),e=>e.status===400);
 await assert.rejects(mdt.createRecord(ctx,{key:'fine',clientKey:key(),fields:{...fields,linkedRecordId:'999999999'}}),e=>e.status===404);
});
async function api(path,method='GET',body=null,user=USER) {
 const code=await mdt.issueCode(belv.guild,belv.members.get(user)),session=await mdt.login(belv.client,code,user===USER?'102':'103',BELV);
 const request=Readable.from(body?[Buffer.from(JSON.stringify(body))]:[]);Object.assign(request,{method,headers:{'content-type':'application/json',authorization:'Bearer '+session.token,'x-mdt-roblox-id':user===USER?'102':'103'},socket:{remoteAddress:'127.0.0.1'}});
 let status,text;const response={writeHead(value){status=value;},end(value){text=value;}};
 await mdt.handleMdtApi(belv.client,request,response,new URL('https://local.test/api/mdt/v1'+path));return{status,body:JSON.parse(text)};
}
test('MDT records API applies creator, time, type, state and sort filters',async()=>{
 for(let i=0;i<22;i++)await mdt.createRecord(ctx,{key:'note',clientKey:key(),fields:{title:'API note '+i,content:'Stored using the actual PostgreSQL engine.'}});
 const result=await api('/records?key=note&mine=1&hours=24&status=published&sort=oldest');assert.equal(result.status,200);assert.equal(result.body.records.length,20);assert.ok(result.body.next);
 assert.ok(result.body.records.every(row=>row.createdBy===USER&&row.key==='note'));const ids=result.body.records.map(row=>Number(row.id));assert.deepEqual(ids,[...ids].sort((a,b)=>a-b));
 const next=await api('/records?key=note&mine=1&sort=oldest&before='+result.body.next);assert.equal(next.body.records.length,2);
});
test('denied MDT edit keeps an authorized session logged in',async()=>{
 const result=await api('/records/'+record.id,'PATCH',{revision:record.revision,fields:{}},OTHER);assert.equal(result.status,403);assert.equal(result.body.relogin,false);
});
test('disabled MDT types disappear and cannot be queried',async()=>{
 settings=await mdt.saveMdtOwnerConfig(belv.guild,OWNER,{...settings,disabledTypes:['fine']});ctx.settings=settings;
 assert.ok(!mdt.definitions(ctx.guild,ctx.member,settings).some(row=>row.key==='fine'));const result=await api('/records?key=fine');assert.equal(result.status,403);assert.equal(result.body.relogin,false);
});
test('MDT member removal invalidates current sessions',async()=>{
 const code=await mdt.issueCode(belv.guild,belv.members.get(OTHER)),session=await mdt.login(belv.client,code,'103',BELV);
 settings=await mdt.updateMdtMember(belv.guild,OWNER,{discordId:OTHER},true);await assert.rejects(mdt.authorize(belv.client,'Bearer '+session.token,'103'),e=>e.status===401);ctx.settings=settings;
});
test('web ticket creation stores the opening question and separate controls',async()=>{
 webTicket=await web.createWebTicket(support.client,{id:USER,username:'qa_user'},{subject:'Connection problem',category:'technical',content:'A'.repeat(4000),clientKey:'web_first_request_key_123'});
 assert.equal(webTicket.discord_state,'synced');const data=await web.getWebTicket(webTicket.id,USER);assert.equal(data.messages[0].content.length,4000);assert.notEqual(data.messages[0].discord_message_id,webTicket.control_message_id);
});
test('repeating a web form does not duplicate the ticket',async()=>{
 const ticket=await web.createWebTicket(support.client,{id:USER,username:'qa_user'},{subject:'Connection problem',category:'technical',content:'A'.repeat(4000),clientKey:'web_first_request_key_123'});assert.equal(String(ticket.id),String(webTicket.id));
 await assert.rejects(web.createWebTicket(support.client,{id:USER,username:'qa_user'},{subject:'Changed subject',category:'technical',content:'A'.repeat(4000),clientKey:'web_first_request_key_123'}),/más tartalommal/);
});
test('web limits count active cases and deny excess tickets',async()=>{
 await web.createWebTicket(support.client,{id:USER,username:'qa_user'},{subject:'Second case',category:'bug',content:'Steps for reproduction',clientKey:key()});
 await assert.rejects(web.createWebTicket(support.client,{id:USER,username:'qa_user'},{subject:'Third case',category:'bug',content:'Steps for reproduction',clientKey:key()}),/Legfeljebb 2/);
});
test('web notes are hidden from the customer and from other users',async()=>{
 await web.addInternalNote(webTicket.id,{id:OWNER,username:'Owner'},'Staff-only note');assert.ok(!(await web.getWebTicket(webTicket.id,USER)).messages.some(row=>row.internal));assert.ok((await web.getWebTicket(webTicket.id,OWNER,true)).messages.some(row=>row.internal));assert.equal(await web.getWebTicket(webTicket.id,OTHER),null);
});
test('long web conversations show latest messages and permit older pagination',async()=>{
 await app.database.query("INSERT INTO nexabot_web_support_messages(ticket_id,author_id,author_name,source,content) SELECT $1,$2,'QA','web','Message '||i FROM generate_series(1,505) i",[webTicket.id,USER]);
 const data=await web.getWebTicket(webTicket.id,USER);assert.equal(data.messages.length,500);assert.equal(data.messages.at(-1).content,'Message 505');assert.ok(data.previous);const earlier=await web.getWebTicket(webTicket.id,USER,false,data.previous);assert.ok(earlier.messages.length>=6);
});
test('web stale actions fail without replacing the saved state',async()=>{
 const state=(await web.getWebTicket(webTicket.id,USER)).ticket;await web.manageWebTicket(support.client,webTicket.id,{id:OWNER,username:'Owner'},'claim','',{revision:state.revision});
 await assert.rejects(web.manageWebTicket(support.client,webTicket.id,{id:OWNER,username:'Owner'},'priority','urgent',{revision:state.revision}),/meg(változott|változott)/);
});
test('failed Discord delivery preserves the web ticket and all opening content',async()=>{
 const original=support.guild.channels.create;support.guild.channels.create=async()=>{throw new Error('Discord permission failure');};
 try{const ticket=await web.createWebTicket(support.client,{id:OTHER,username:'other'},{subject:'Discord unavailable',category:'other',content:'Keep this entire question',clientKey:key()});assert.equal(ticket.discord_state,'failed');assert.equal((await web.getWebTicket(ticket.id,OTHER)).messages[0].content,'Keep this entire question');}finally{support.guild.channels.create=original;}
});
test('ticket extra questions serialize as a valid five-field Discord modal',async()=>{
 const config=app.config.getGuildConfig(BELV);await app.config.setGuildConfig(BELV,{...config,modules:{...config.modules,tickets:true},tickets:{...config.tickets,questions:[{label:'Roblox name',required:true},{label:'Evidence link'}],customTypes:[{key:'appeal-1',label:'Appeal'}],enabledTypes:['support','appeal-1'],agentRoleIds:[ROLE],transcriptOnClose:false,allowCreatorClose:false}});
 const interaction=belv.interaction('ticket_category_select',USER);interaction.values=['appeal-1'];await app.load('ticket-operations').handleTicketOperations(interaction,()=>{});assert.equal(interaction.modal.toJSON().components.length,5);
 let created=false;const submit=belv.interaction('ticket_open:appeal-1:guild',USER,null,{subject:'Appeal test',content:'Explain the decision',priority:'sürgős',extra_1:'qa_user',extra_2:'https://local.test'});
 await app.load('ticket-operations').handleTicketOperations(submit,async(i,type,details,options)=>{created=true;assert.equal(type,'appeal-1');assert.equal(options.metadata.priority,'urgent');assert.equal(options.metadata.extra['Roblox name'],'qa_user');});assert.equal(created,true);
});
test('generic ticket staff can assign, leave private notes and inspect history',async()=>{
 const ch=belv.channel('ticket-test');const ticket=(await app.database.query("INSERT INTO nexabot_tickets(guild_id,channel_id,owner_id,category,subject) VALUES($1,$2,$3,'support','Test generic ticket') RETURNING *",[BELV,ch.id,USER])).rows[0];
 const ops=app.load('ticket-operations');assert.equal(ops.isTicketStaff(belv.members.get(OTHER)),true);
 const note=belv.interaction('ticket_note_submit',OTHER,ch,{value:'Private review note'});await ops.handleTicketOperations(note);assert.match(String(note.result),/mentve/);
 const denied=belv.interaction('ticket_notes',USER,ch);await ops.handleTicketOperations(denied);assert.match(String(denied.result),/staff/);
 const assign=belv.interaction('ticket_assign_submit',OTHER,ch,{value:OTHER});await ops.handleTicketOperations(assign);assert.match(String(assign.result),/mentve/);
 const events=(await app.database.query('SELECT * FROM nexabot_ticket_events WHERE ticket_id=$1 ORDER BY revision',[ticket.id])).rows;assert.equal(events.length,2);assert.equal(events[1].actor_id,OTHER);
 const manage=belv.interaction('ticket_manage',OTHER,ch);await ops.handleTicketOperations(manage);assert.ok(manage.result.components.length<=5);manage.result.components.forEach(row=>row.toJSON());
 const close=belv.interaction('ticket_close_submit',USER,ch,{value:'I wish to close'});await ops.handleTicketOperations(close);assert.match(String(close.result),/staff/);assert.equal((await app.database.query('SELECT status FROM nexabot_tickets WHERE id=$1',[ticket.id])).rows[0].status,'open');
});
test('Support pause is preserved across configuration reload and 500 simulated joins',async()=>{
 const result=await app.load('support-moderation').setSupportModerationPaused(support.guild,OWNER,true);assert.equal(result.paused,true);
 const handlers={};const fakeClient={...support.client,on(event,handler){handlers[event]=handler;}};app.load('security').registerSecurity(fakeClient);
 let punishments=0;const member=support.members.get(USER);for(const method of ['kick','ban','timeout'])member[method]=async()=>{punishments++;};
 const join=handlers.guildMemberAdd;assert.equal(typeof join,'function');for(let i=0;i<500;i++)await join(member);assert.equal(punishments,0);
 await app.config.initConfigStore();assert.equal(app.config.isSupportModerationPaused(SUPPORT),true);assert.equal(app.config.moduleEnabled(SUPPORT,'protection'),false);assert.equal(app.config.moduleEnabled(SUPPORT,'moderation'),false);
});
test('only the main owner can pause or resume official Support moderation',async()=>{await assert.rejects(app.load('support-moderation').setSupportModerationPaused(support.guild,USER,false),e=>e.status===403);assert.equal(app.config.isSupportModerationPaused(SUPPORT),true);});
test('a failed pause write still blocks immediate automatic punishment',async()=>{
 await app.config.setGuildConfig(SUPPORT,{...app.config.getGuildConfig(SUPPORT),supportModeration:{paused:false}});app.failNext(Object.assign(new Error('Temporary constraint failure'),{code:'23514'}));
 const result=await app.load('support-moderation').setSupportModerationPaused(support.guild,OWNER,true);assert.equal(result.paused,true);assert.equal(result.complete,false);assert.equal(app.config.isSupportModerationPaused(SUPPORT),true);
});
test('owner diagnostics expose no secrets and reject delegated users',async()=>{
 const diagnostics=app.load('owner-diagnostics');await assert.rejects(diagnostics.diagnosticState(belv.client,USER),e=>e.status===403);const state=await diagnostics.diagnosticState(belv.client,OWNER,true);assert.ok(state.checks.some(row=>row.name==='PostgreSQL'&&row.ok));assert.ok(!JSON.stringify(state).includes(process.env.DATABASE_URL));
});
test('only enabled native AutoMod rules resume after an owner pause',async()=>{
 const rules=new Collection([['100000000000005001',{id:'100000000000005001',enabled:true}],['100000000000005002',{id:'100000000000005002',enabled:false}],['100000000000005003',{id:'100000000000005003',enabled:true}]]);for(const rule of rules.values())rule.edit=async data=>{rule.enabled=data.enabled;};support.guild.autoModerationRules.fetch=async()=>rules;
 const service=app.load('support-moderation');await service.setSupportModerationPaused(support.guild,OWNER,true);assert.ok([...rules.values()].every(rule=>!rule.enabled));
 const result=await service.setSupportModerationPaused(support.guild,OWNER,false);assert.equal(result.paused,false);assert.equal(rules.get('100000000000005001').enabled,true);assert.equal(rules.get('100000000000005002').enabled,false);assert.equal(rules.get('100000000000005003').enabled,true);
 await service.setSupportModerationPaused(support.guild,OWNER,true);
});
test('failed resume persistence leaves NEXA moderation paused',async()=>{
 const paused=app.config.getGuildConfig(SUPPORT);await app.config.setGuildConfig(SUPPORT,{...paused,supportModeration:{...paused.supportModeration,paused:true,nativeRules:[]}});
 app.failNext(Object.assign(new Error('Settings write rejected'),{code:'23514'}),/INSERT INTO nexabot_guild_configs/);
 await assert.rejects(app.load('support-moderation').setSupportModerationPaused(support.guild,OWNER,false));assert.equal(app.config.isSupportModerationPaused(SUPPORT),true);
});
test('MDT provisioning only creates missing rooms and is repeatable without duplicates',async()=>{
 const before=new Map([...belv.channels.values()].map(ch=>[ch.id,{name:ch.name,topic:ch.topic,parentId:ch.parentId}])),roles=belv.roles.size;
 const result=await mdt.provisionMdtOwnerChannels(belv.guild,OWNER,await mdt.getSettings(BELV));assert.ok(result.created.length>0);assert.equal(belv.roles.size,roles);
 for(const[id,snapshot]of before)assert.deepEqual({name:belv.channels.get(id).name,topic:belv.channels.get(id).topic,parentId:belv.channels.get(id).parentId},snapshot);
 const again=await mdt.provisionMdtOwnerChannels(belv.guild,OWNER,await mdt.getSettings(BELV));assert.equal(again.created.length,0);assert.equal(again.reused.length,mdt.MDT_CHANNELS.length);
});
test('generic ticket opening honors configured limits and includes custom questions',async()=>{
 const category=belv.channel('Private tickets',ChannelType.GuildCategory),panel=belv.channel('Ticket panel'),config=app.config.getGuildConfig(BELV);
 await app.config.setGuildConfig(BELV,{...config,channels:{...config.channels,ticketCategory:category.id,ticketPanel:panel.id},roles:{...config.roles,staff:ROLE},tickets:{...config.tickets,maxOpenPerUser:2}});
 const service=app.load('interactions'),first=belv.interaction('',USER);
 await service.createTicket(first,'appeal-1',null,{metadata:{subject:'Test custom request',content:'Full original description',extra:{'Roblox-név':'qa_user'}}});assert.match(String(first.result),/Elkészült|ready/);
 const ch=[...belv.channels.values()].find(ch=>ch.topic==='nexabot-ticket|'+USER+'|appeal-1');assert.ok(ch);assert.ok([...ch.messages.cache.values()][0].embeds[0].data.fields.some(f=>f.name==='Roblox-név'));assert.equal(ch.createOptions.permissionOverwrites[0].id,belv.guild.members.me.id);
 const second=belv.interaction('',USER);await service.createTicket(second,'support');assert.match(String(second.result),/Elkészült|ready/);
 const third=belv.interaction('',USER);await service.createTicket(third,'support');assert.match(String(third.result),/Legfeljebb 2/);assert.equal((await app.database.query('SELECT * FROM nexabot_ticket_open_locks')).rows.length,0);
});
test('failed generic control sending keeps the saved ticket recoverable by slash command',async()=>{
 const original=belv.guild.channels.create;let failed;
 belv.guild.channels.create=async options=>{failed=await original(options);failed.send=async()=>{throw new Error('Missing Discord send permission');};return failed;};
 try{const interaction=belv.interaction('',OTHER);await app.load('interactions').createTicket(interaction,'support');assert.match(String(interaction.result),/ticket javitas/);assert.equal((await app.database.query('SELECT discord_state FROM nexabot_tickets WHERE channel_id=$1',[failed.id])).rows[0].discord_state,'failed');}finally{belv.guild.channels.create=original;}
 failed.send=async payload=>{payload.components.forEach(row=>row.toJSON());return{id:'100000000000009999'};};
 const command=belv.interaction('',OTHER,failed);command.options={getSubcommand:()=> 'javitas'};await app.load('ticket-operations').handleTicketCommand(command);assert.match(String(command.result),/helyreállítva/);assert.equal((await app.database.query('SELECT discord_state FROM nexabot_tickets WHERE channel_id=$1',[failed.id])).rows[0].discord_state,'synced');
});
test('configured ticket staff can operate web Discord controls without guild moderation permission',async()=>{
 const actor=support.members.get(OTHER);assert.equal(actor.permissions.has(1n),false);await web.requireOperator(support.client,actor.user);
 const interaction=support.interaction('websupport_priority_submit:'+webTicket.id,OTHER,support.channels.get(webTicket.channel_id),{value:'magas'});await web.handleDiscordSupportInteraction(interaction);assert.match(String(interaction.result),/Ticket #/);assert.equal((await web.getWebTicket(webTicket.id,USER)).ticket.priority,'high');
});
test('disabled web ratings and optional close reasons are enforced by the server',async()=>{
 const config=app.config.getGuildConfig(SUPPORT);await app.config.setGuildConfig(SUPPORT,{...config,tickets:{...config.tickets,ratingEnabled:false,requireCloseReason:false}});
 await web.manageWebTicket(support.client,webTicket.id,{id:OWNER,username:'Owner'},'status','closed');await assert.rejects(web.rateWebTicket(webTicket.id,USER,5),/ki van kapcsolva/);
 assert.ok((await web.getWebTicket(webTicket.id,USER)).ticket.close_reason);
});
test('ticket panel has sixteen valid category choices and disables unavailable support shortcut',()=>{
 const customTypes=Array.from({length:10},(_,i)=>({key:'custom-'+i,label:'Custom '+i})),base=['support','application','report','purchase','partnership','other'];
 const panel=app.load('panels').ticketPanel(null,'hu',[...base,...customTypes.map(t=>t.key)],{},customTypes);assert.equal(panel.components[0].toJSON().components[0].options.length,16);
 const limited=app.load('panels').ticketPanel(null,'hu',['report']);assert.equal(limited.components[1].toJSON().components[0].disabled,true);
});
test('trusted domains allow real subdomains and reject lookalike and userinfo hosts',()=>{
 const {containsUntrustedLink}=app.load('automod-policy');for(const text of ['https://roblox.com/home','https://www.roblox.com/'])assert.equal(containsUntrustedLink(text,['roblox.com']),false);
 for(const text of ['https://roblox.com.evil.example/','https://roblox.com@evil.example/','https://evilroblox.com/'])assert.equal(containsUntrustedLink(text,['roblox.com']),true);
});
test('custom moderation mention, caps and emoji thresholds affect live event handling',async()=>{
 await app.config.grantGuildPlan(BELV,'ultimate',{grantedBy:OWNER});const config=app.config.getGuildConfig(BELV);
 await app.config.setGuildConfig(BELV,{...config,modules:{...config.modules,protection:true},protection:{...config.protection,mode:'alerts',deleteMessages:true,mentionLimit:2,emojiLimit:2,capsPercent:50,massMention:true,capsSpam:true,emojiSpam:true,spam:false,flood:false,repeatedMessage:false,invites:false,links:false,scamLinks:false,badWords:false}});
 const handlers={};app.load('security').registerSecurity({on(event,handler){handlers[event]=handler;}});const ch=belv.channel('protected'),member=belv.members.get(USER);let deleted=0;
 const message=text=>({guild:belv.guild,member,author:member.user,channel:ch,channelId:ch.id,content:text,embeds:[],attachments:new Collection(),mentions:{users:new Collection(),roles:new Collection(),everyone:false},async delete(){deleted++;}});
 const mention=message('mention threshold test');mention.mentions.users=new Collection([['1',{}],['2',{}]]);await handlers.messageCreate(mention);await handlers.messageCreate(message('ABCDEFGHabcdefghABCDEFGH'));await handlers.messageCreate(message('😀😀'));
 assert.equal(deleted,3);
});
test('ticket command serializes all three recovery and management subcommands',()=>{const command=app.load('ticket-operations').buildTicketCommand().toJSON();assert.equal(command.name,'ticket');assert.deepEqual(command.options.map(o=>o.name),['allapot','kezeles','javitas']);assert.equal(command.default_member_permissions,null);});
test('ticket status includes every part of the original customer description',async()=>{
 const ch=belv.channel('ticket-full-description');await app.database.query("INSERT INTO nexabot_tickets(guild_id,channel_id,owner_id,category,subject,form_data) VALUES($1,$2,$3,'support','Long original request',$4)",[BELV,ch.id,USER,JSON.stringify({content:'X'.repeat(3000),extra:{Question:'Answer'}})]);
 const status=belv.interaction('ticket_status',USER,ch);await app.load('ticket-operations').handleTicketOperations(status);const fields=status.result.embeds[0].toJSON().fields;assert.equal(fields.filter(row=>row.name.startsWith('Ügyfél leírása')).map(row=>row.value).join('').length,3000);
});
test('additional ticket roles can manage participants with fresh role checks',async()=>{
 const ch=belv.channel('ticket-participants'),config=app.config.getGuildConfig(BELV);await app.config.setGuildConfig(BELV,{...config,roles:{...config.roles,staff:null},tickets:{...config.tickets,agentRoleIds:[ROLE]}});
 await app.database.query("INSERT INTO nexabot_tickets(guild_id,channel_id,owner_id,category) VALUES($1,$2,$3,'support')",[BELV,ch.id,USER]);let changed=false;ch.permissionOverwrites.edit=async()=>{changed=true;};
 const add=belv.interaction('ticket_user_add',OTHER,ch);add.values=['100000000000000011'];await app.load('ticket-operations').handleTicketOperations(add);assert.equal(changed,true);
 const removeOwner=belv.interaction('ticket_user_remove',OTHER,ch);removeOwner.values=[USER];await app.load('ticket-operations').handleTicketOperations(removeOwner);assert.match(String(removeOwner.result),/nem távolítható/);
 belv.members.get(OTHER).roles.cache.clear();changed=false;const revoked=belv.interaction('ticket_user_add',OTHER,ch);revoked.values=['100000000000000011'];await app.load('ticket-operations').handleTicketOperations(revoked);assert.equal(changed,false);assert.match(String(revoked.result),/nincs hozzáférés/);belv.members.get(OTHER).roles.cache.set(ROLE,belv.roles.get(ROLE));
});
test('ticket rename preserves closed status and refuses unrelated channels',async()=>{
 const ch=belv.channel('lezart-test');await app.database.query("INSERT INTO nexabot_tickets(guild_id,channel_id,owner_id,category,status) VALUES($1,$2,$3,'support','closed')",[BELV,ch.id,USER]);const rename=belv.interaction('ticket_rename_submit',OTHER,ch,{ticket_new_name:'New ticket name'});await app.load('ticket-operations').handleTicketOperations(rename);assert.equal(ch.name,'lezart-new-ticket-name');
 const unrelated=belv.channel('unrelated');const denied=belv.interaction('ticket_rename_submit',OTHER,unrelated,{ticket_new_name:'Changed'});await app.load('ticket-operations').handleTicketOperations(denied);assert.equal(unrelated.name,'unrelated');assert.match(String(denied.result),/nem aktív NEXA-ticket/);
});
